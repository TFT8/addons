name = "TFT8 Dismount";  //Name of Mod, not a bad idea to keep the version number in it for each mod as another way to show which version members are using.
author = "Ampersand"; // obviously, the author of the mod
logo = "mod.paa"; //logo displayed in main menu
logoOver = "mod.paa"; //when the mouse is over on the main menu icon can change into another image
tooltip = "TFT8 Dismount";  // text visible when mouseover main menu icon
tooltipOwned = "TFT8 Dismount"; // supposed to change the tooltip text when mouseover main menu icon, does not seem to work?
logoSmall = "mod.paa"; //small icon displayed by items added by the mod
overview = "Get out where you look. By <t color='#266B26'><a href='http://tft8.com'>Task Force Tempor 8</a></t>."; // Config - extensions - description - 
description = "Get out where you look. By Task Force Temopr 8."; //
picture = "mod.paa"; //picture displayed in Expansions Menu redundant with below
overviewPicture = "mod.paa"; // the 3:2 format picture on the overview page in the expansions menu
overviewText = "TFT8 Dismount"; //
actionName = "TFT8 web";  //Names the button that links to the website URL accessed from the extension menu, can only be 8 characters long
action = "http://tft8.com"; //Website URL, that can accessed from the extension menu
