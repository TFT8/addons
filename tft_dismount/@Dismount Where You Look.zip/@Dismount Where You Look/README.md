# TFT Dismount

Adds new GET OUT action to enable exiting vehicle at the enter/exit point in the same compartment and closest to camera view. Hooks on Vanilla Get Out keybind.